/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.controller;

import com.example.model.Restaurant;
import com.example.service.RequestService;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class RequestController {
    
    @Autowired
    private RequestService requestService;
    
     public List<Restaurant> restList = new ArrayList<>();
    
    @RequestMapping (value="/SaveRequest", method = RequestMethod.POST)
    public void addRequest(@RequestBody Restaurant restaurant){
        System.out.println("rhtgere");
        requestService.addRequest(restaurant);
    }
    
    //Not Accepted
    @RequestMapping(value="/getRequest")
    public List<Restaurant> getRestaurantRequests()
    {
        restList = requestService.getRequests();
        return restList;
    }
       
    //Accepted
    @RequestMapping(value="/getAcceptedRestaurants")
    public List<Restaurant> getAcceptedRestaurants()
    {
        restList = requestService.getAcceptedRestaurants();
        return restList;
    }
        
           @RequestMapping(value="/acceptedRest", method = RequestMethod.GET)
        public ModelAndView acceptedRest(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("acceptedRest");
                return modelAndView;
        }
      
        @RequestMapping (value="/deleteRequest", method = RequestMethod.DELETE)
        public void deleteRequest (@RequestBody Restaurant restaurant){
            System.out.println("rhtgere");
            requestService.deleteRequest(restaurant);
        }
        
        
            // Update a Restaurant
    @RequestMapping(value="/updateRequest/{restId}", method = RequestMethod.PUT)
    public Restaurant updateRequest(@PathVariable(value = "restId") int restId) {
        Restaurant restaurant = requestService.findByRestaurantId(restId);
        
        if(restaurant != null) {
            restaurant.setStatus(true);
        }

        Restaurant updatedRequest = requestService.saveRequest(restaurant);
        return updatedRequest;
    }
    
    
     @RequestMapping (value="/deleteRestaurant", method = RequestMethod.DELETE)
        public void deleteRestaurant (@RequestBody Restaurant restaurant){
            System.out.println("rhtgere");
            requestService.deleteRestaurant(restaurant);
        }       
}
