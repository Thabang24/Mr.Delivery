/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "menu")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Menu.findAll", query = "SELECT m FROM Menu m")
    , @NamedQuery(name = "Menu.findByMenuItemId", query = "SELECT m FROM Menu m WHERE m.menuItemId = :menuItemId")
    , @NamedQuery(name = "Menu.findByRestId", query = "SELECT m FROM Menu m WHERE m.restId = :restId")
    , @NamedQuery(name = "Menu.findByItemDescription", query = "SELECT m FROM Menu m WHERE m.itemDescription = :itemDescription")
    , @NamedQuery(name = "Menu.findByItemName", query = "SELECT m FROM Menu m WHERE m.itemName = :itemName")
    , @NamedQuery(name = "Menu.findByItemPrice", query = "SELECT m FROM Menu m WHERE m.itemPrice = :itemPrice")})
public class Menu implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "menu_item_id")
    private Integer menuItemId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "rest_id")
    private int restId;
    @Size(max = 255)
    @Column(name = "item_description")
    private String itemDescription;
    @Size(max = 255)
    @Column(name = "item_name")
    private String itemName;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "item_price")
    private Float itemPrice;

    public Menu() {
    }

    public Menu(Integer menuItemId) {
        this.menuItemId = menuItemId;
    }

    public Menu(Integer menuItemId, int restId) {
        this.menuItemId = menuItemId;
        this.restId = restId;
    }

    public Integer getMenuItemId() {
        return menuItemId;
    }

    public void setMenuItemId(Integer menuItemId) {
        this.menuItemId = menuItemId;
    }

    public int getRestId() {
        return restId;
    }

    public void setRestId(int restId) {
        this.restId = restId;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Float getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(Float itemPrice) {
        this.itemPrice = itemPrice;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (menuItemId != null ? menuItemId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Menu)) {
            return false;
        }
        Menu other = (Menu) object;
        if ((this.menuItemId == null && other.menuItemId != null) || (this.menuItemId != null && !this.menuItemId.equals(other.menuItemId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.example.model.Menu[ menuItemId=" + menuItemId + " ]";
    }
    
}
