/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


 //Selecting all text elements
    var package = document.forms['vform']['package'];
    var rest_name = document.forms['vform']['rest_name'];
    var rest_address = document.forms['vform']['rest_address'];
    var rest_city = document.forms['vform']['rest_city'];
    var zip_code = document.forms['vform']['zip_code'];
    var owner_firstName = document.forms['vform']['owner_firstName'];
    var owner_lastName = document.forms['vform']['owner_lastName'];
    var owner_cellNum = document.forms['vform']['owner_cellNum'];
    var owner_email = document.forms['vform']['owner_email'];
    var rest_faxNum = document.forms['vform']['rest_faxNum'];
    var rest_phoneNum = document.forms['vform']['rest_phoneNum'];
    var openTime = document.forms['vform']['openTime'];
    var closeTime = document.forms['vform']['closeTime'];
    var info = document.forms['vform']['info'];
   
    // Selecting all error display elements
var package_error = document.getElementById('package');
var rest_name_error= document.getElementById('rest_name');
var rest_address_error = document.getElementById('rest_address');
var rest_city_error= document.getElementById('rest_city');
var  zip_code_error= document.getElementById('zip_code');
var owner_firstName_error= document.getElementById('owner_firstName');
var owner_lastName_error = document.getElementById('owner_lastName');
var owner_cellNum_error = document.getElementById('owner_cellNum');
var owner_email_error= document.getElementById('owner_email');
var rest_faxNum_error= document.getElementById('rest_faxNum');
var rest_phoneNum_error = document.getElementById('rest_phoneNum');
var openTime_error= document.getElementById('openTime');
var closeTime_error = document.getElementById('closeTime');
var info_error = document.getElementById('info');

// SETTING ALL EVENT LISTENERS
package.addEventListener('blur', packageVerify, true);
rest_name.addEventListener('blur', rest_nameVerify, true);
rest_address.addEventListener('blur', rest_addressVerify, true);
rest_city.addEventListener('blur', rest_cityVerify, true);
zip_code.addEventListener('blur', zip_codeVerify, true);
owner_firstName.addEventListener('blur', owner_firstNameVerify, true);
owner_lastName.addEventListener('blur', owner_lastNameVerify, true);
owner_cellNum.addEventListener('blur', owner_cellNumVerify, true);
owner_email.addEventListener('blur', owner_emailVerify, true);
rest_faxNum.addEventListener('blur', rest_faxNumVerify, true);
rest_phoneNum.addEventListener('blur', rest_phoneNumVerify, true);
openTime.addEventListener('blur', openTimeVerify, true);
closeTime.addEventListener('blur', closeTimeVerify, true);
info.addEventListener('blur', infoVerify, true);

// validation function
function Validate() {
  // validate package
  if (package.value == "") {
    package.style.border = "1px solid red";
    document.getElementById('package_div').style.color = "red";
    package_error.textContent = "Username is required";
    username.focus();
    return false;
  }
  // validate restaurant name
  if (rest_name.value.length < 3) {
    rest_name.style.border = "1px solid red";
    document.getElementById('rest_name_div').style.color = "red";
    rest_name_error.textContent = "restaurant name must be at least 3 characters";
    rest_name.focus();
    return false;
  }
  // validate email
  if (rest_address.value === "") {
    rest_address.style.border = "1px solid red";
    document.getElementById('email_div').style.color = "red";
    rest_address_error.textContent = "restaurant address is required";
    rest_address.focus();
    return false;
  }
  // validate password
  if (rest_city.value === "") {
    rest_city.style.border = "1px solid red";
    document.getElementById('password_div').style.color = "red";
    rest_city.style.border = "1px solid red";
    rest_city_error.textContent = "rest_city is required";
    rest_city.focus();
    return false;
  }
    if (zip_code.value === "") {
    zip_code.style.border = "1px solid red";
    document.getElementById('zip_code_div').style.color = "red";
    zip_code.style.border = "1px solid red";
    zip_code_error.textContent = "zip_code is required";
    zip_code.focus();
    return false;
  }
    if (owner_firstName.value === "") {
    owner_firstName.style.border = "1px solid red";
    document.getElementById('owner_firstName_div').style.color = "red";
    owner_firstName.style.border = "1px solid red";
    owner_firstName_error.textContent = "owner_firstName is required";
    owner_firstName.focus();
    return false;
  }
    if (owner_lastName.value === "") {
    owner_lastName.style.border = "1px solid red";
    document.getElementById('owner_lastName_div').style.color = "red";
    owner_lastName.style.border = "1px solid red";
    owner_lastName_error.textContent = "owner_lastName is required";
    owner_lastName.focus();
    return false;
  }
    if (owner_cellNum.value == "") {
    owner_cellNum.style.border = "1px solid red";
    document.getElementById('owner_cellNum_div').style.color = "red";
    owner_cellNum.style.border = "1px solid red";
    owner_cellNum_error.textContent = "owner_cellNum is required";
    owner_cellNum.focus();
    return false;
  }
    if (owner_email.value == "") {
    owner_email.style.border = "1px solid red";
    document.getElementById('owner_email_div').style.color = "red";
    owner_email.style.border = "1px solid red";
   owner_email_error.textContent = "owner_email is required";
    owner_email.focus();
    return false;
  }
    if (rest_faxNum.value == "") {
    rest_faxNum.style.border = "1px solid red";
    document.getElementById('rest_faxNum_div').style.color = "red";
    rest_faxNum.style.border = "1px solid red";
    rest_faxNum_error.textContent = "rest_faxNum is required";
    rest_faxNum.focus();
    return false;
  }
    if (rest_phoneNum.value == "") {
    rest_phoneNum.style.border = "1px solid red";
    document.getElementById('rest_phoneNum_div').style.color = "red";
    rest_phoneNum.style.border = "1px solid red";
    rest_phoneNum_error.textContent = "phone number is required";
    rest_phoneNum.focus();
    return false;
  }
    if (openTime.value == "") {
    openTime.style.border = "1px solid red";
    document.getElementById('openTime_div').style.color = "red";
    openTime.style.border = "1px solid red";
    openTime_error.textContent = "open time is required";
    openTime.focus();
    return false;
  }
    if (closeTime.value == "") {
    closeTime.style.border = "1px solid red";
    document.getElementById('closeTime_div').style.color = "red";
    closeTime.style.border = "1px solid red";
    closeTime_error.textContent = "closeTime is required";
    closeTime.focus();
    return false;
  }
    if (info.value == "") {
    password.style.border = "1px solid red";
    document.getElementById('info_div').style.color = "red";
    info.style.border = "1px solid red";
   info_error.textContent = "Info is required";
    info.focus();
    return false;
  }
  
}

  // event handler functions
function packageVerify() {
  if (package.value != "") {
   package.style.border = "1px solid #5e6e66";
   document.getElementById('package_div').style.color = "#5e6e66";
   package_error.innerHTML = "";
   return true;
  }
}
function rest_nameVerify() {
  if (rest_name.value != "") {
  	rest_name.style.border = "1px solid #5e6e66";
  	document.getElementById('rest_name_div').style.color = "#5e6e66";
  	rest_name_error.innerHTML = "";
  	return true;
  }
}
function rest_addressVerify() {
  if (rest_address.value != "") {
   rest_address.style.border = "1px solid #5e6e66";
   document.getElementById('rest_address_div').style.color = "#5e6e66";
   rest_address_error.innerHTML = "";
   return true;
  }
}
function rest_cityVerify() {
  if (rest_city.value != "") {
  	rest_city.style.border = "1px solid #5e6e66";
  	document.getElementById('rest_city_div').style.color = "#5e6e66";
  	rest_city_error.innerHTML = "";
  	return true;
  }
}
function zip_codeVerify() {
  if (zip_code.value != "") {
   zip_code.style.border = "1px solid #5e6e66";
   document.getElementById('zip_code_div').style.color = "#5e6e66";
  zip_code_error.innerHTML = "";
   return true;
  }
}
function owner_firstNameVerify() {
  if (owner_firstName.value != "") {
  	owner_firstName.style.border = "1px solid #5e6e66";
  	document.getElementById('owner_firstName_div').style.color = "#5e6e66";
  	owner_firstName_error.innerHTML = "";
  	return true;
  }
}
function owner_lastNameVerify() {
  if (owner_lastName.value != "") {
   owner_lastName.style.border = "1px solid #5e6e66";
   document.getElementById('owner_lastName_div').style.color = "#5e6e66";
   owner_lastName_error.innerHTML = "";
   return true;
  }
}
function owner_cellNumVerify() {
  if (owner_cellNum.value != "") {
  	email.style.border = "1px solid #5e6e66";
  	document.getElementById('owner_cellNum_div').style.color = "#5e6e66";
  	owner_cellNum_error.innerHTML = "";
  	return true;
  }
}
function owner_emailVerify() {
  if (owner_email.value != "") {
   owner_email.style.border = "1px solid #5e6e66";
   document.getElementById('owner_email_div').style.color = "#5e6e66";
   owner_email_error.innerHTML = "";
   return true;
  }
}
function rest_faxNumVerify() {
  if (rest_faxNum.value != "") {
  	rest_faxNum.style.border = "1px solid #5e6e66";
  	document.getElementById('rest_faxNum_div').style.color = "#5e6e66";
  	rest_faxNum_error.innerHTML = "";
  	return true;
  }
}
function rest_phoneNumVerify() {
  if (rest_phoneNum.value != "") {
   rest_phoneNum.style.border = "1px solid #5e6e66";
   document.getElementById('rest_phoneNum_div').style.color = "#5e6e66";
  rest_phoneNum_error.innerHTML = "";
   return true;
  }
}
function openTimeVerify() {
  if (openTime.value != "") {
  	openTime.style.border = "1px solid #5e6e66";
  	document.getElementById('openTime_div').style.color = "#5e6e66";
  	openTime_error.innerHTML = "";
  	return true;
  }
}
function closeTimeVerify() {
  if (closeTime.value != "") {
   closeTime.style.border = "1px solid #5e6e66";
   document.getElementById('closeTime_div').style.color = "#5e6e66";
   closeTime_error.innerHTML = "";
   return true;
  }
}
function infoVerify() {
  if (info.value != "") {
  	info.style.border = "1px solid #5e6e66";
  	document.getElementById('info_div').style.color = "#5e6e66";
  	info_error.innerHTML = "";
  	return true;
  }
}