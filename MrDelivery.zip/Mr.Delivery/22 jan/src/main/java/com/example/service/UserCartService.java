
package com.example.service;

import com.example.model.User;
import com.example.repository.UserCartRepository;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserCartService {
    
    @Autowired
    private UserCartRepository usercartrepository;
    
    public ArrayList<User> getUser(String email)
    {
        return usercartrepository.viewByUserId(email);
    }
}
