/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "restaurant")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Restaurant.findAll", query = "SELECT r FROM Restaurant r")
    , @NamedQuery(name = "Restaurant.findByRestId", query = "SELECT r FROM Restaurant r WHERE r.restId = :restId")
    , @NamedQuery(name = "Restaurant.findByStatus", query = "SELECT r FROM Restaurant r WHERE r.status = :status")
    , @NamedQuery(name = "Restaurant.findByFileName", query = "SELECT r FROM Restaurant r WHERE r.fileName = :fileName")})
public class Restaurant implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "rest_id")
    private Integer restId;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "close_time")
    private String closeTime;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "info")
    private String info;
    @Lob
    @Column(name = "menu_file")
    private byte[] menuFile;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "open_time")
    private String openTime;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "owner_cell_num")
    private String ownerCellNum;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "owner_email")
    private String ownerEmail;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "owner_first_name")
    private String ownerFirstName;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "owner_last_name")
    private String ownerLastName;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "package")
    private String package1;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "rest_address")
    private String restAddress;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "rest_city")
    private String restCity;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "rest_fax_num")
    private String restFaxNum;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "rest_name")
    private String restName;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "rest_phone_num")
    private String restPhoneNum;
    @Column(name = "status")
    private Boolean status;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "zip_code")
    private String zipCode;
    @Size(max = 255)
    @Column(name = "file_name")
    private String fileName;

    public Restaurant() {
    }

    public Restaurant(Integer restId) {
        this.restId = restId;
    }

    public Integer getRestId() {
        return restId;
    }

    public void setRestId(Integer restId) {
        this.restId = restId;
    }

    public String getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(String closeTime) {
        this.closeTime = closeTime;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public byte[] getMenuFile() {
        return menuFile;
    }

    public void setMenuFile(byte[] menuFile) {
        this.menuFile = menuFile;
    }

    public String getOpenTime() {
        return openTime;
    }

    public void setOpenTime(String openTime) {
        this.openTime = openTime;
    }

    public String getOwnerCellNum() {
        return ownerCellNum;
    }

    public void setOwnerCellNum(String ownerCellNum) {
        this.ownerCellNum = ownerCellNum;
    }

    public String getOwnerEmail() {
        return ownerEmail;
    }

    public void setOwnerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }

    public String getOwnerFirstName() {
        return ownerFirstName;
    }

    public void setOwnerFirstName(String ownerFirstName) {
        this.ownerFirstName = ownerFirstName;
    }

    public String getOwnerLastName() {
        return ownerLastName;
    }

    public void setOwnerLastName(String ownerLastName) {
        this.ownerLastName = ownerLastName;
    }

    public String getPackage1() {
        return package1;
    }

    public void setPackage1(String package1) {
        this.package1 = package1;
    }

    public String getRestAddress() {
        return restAddress;
    }

    public void setRestAddress(String restAddress) {
        this.restAddress = restAddress;
    }

    public String getRestCity() {
        return restCity;
    }

    public void setRestCity(String restCity) {
        this.restCity = restCity;
    }

    public String getRestFaxNum() {
        return restFaxNum;
    }

    public void setRestFaxNum(String restFaxNum) {
        this.restFaxNum = restFaxNum;
    }

    public String getRestName() {
        return restName;
    }

    public void setRestName(String restName) {
        this.restName = restName;
    }

    public String getRestPhoneNum() {
        return restPhoneNum;
    }

    public void setRestPhoneNum(String restPhoneNum) {
        this.restPhoneNum = restPhoneNum;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (restId != null ? restId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Restaurant)) {
            return false;
        }
        Restaurant other = (Restaurant) object;
        if ((this.restId == null && other.restId != null) || (this.restId != null && !this.restId.equals(other.restId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.example.model.Restaurant[ restId=" + restId + " ]";
    }
    
}
