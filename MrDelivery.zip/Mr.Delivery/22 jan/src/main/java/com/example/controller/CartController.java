
package com.example.controller;

import com.example.model.ShoppingCart;
import com.example.service.CartService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CartController {
    
    @Autowired
    private CartService cartservice;
    
    @RequestMapping(method = RequestMethod.POST, value = "/SaveCart")
    
    public void SaveCart(@RequestBody ShoppingCart carts)
    {
        cartservice.SaveCart(carts);
    }
    
    @RequestMapping(method = RequestMethod.DELETE, value = "/DeleteCart/{user_id}")
    
        public void DeleteCart(@PathVariable int user_id)
        {
            cartservice.DeleteCart(user_id);
        }
        
        @RequestMapping(value = "/emptyCustomerCart/{user_id}",method = RequestMethod.DELETE)
        public void emptyCustomerCart(@PathVariable(value = "user_id") int user_id){
            List<ShoppingCart> cart = cartservice.getCart(user_id);
            for (int item = 0; item < cart.size(); item++)
            {
                if(cart.get(item).getUserId() == user_id)
                    cartservice.DeleteCart(cart.get(item).getCartId());
            }
        }
        
    

    @RequestMapping(method = RequestMethod.PUT, value="/UpdateCart/{user_id}")
    
    public void UpdateCart(@RequestBody ShoppingCart carts, @PathVariable int user_id)
    {
        cartservice.updateCart(user_id, carts);
    }
    
    
    
    @RequestMapping("/GetCarts")
    
    public List<ShoppingCart> getAllCarts()
    {
        return cartservice.getAllCarts();
    }
}
