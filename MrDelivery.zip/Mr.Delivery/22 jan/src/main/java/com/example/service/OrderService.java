
package com.example.service;

import com.example.model.Orders;
import com.example.repository.OrderRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {
   
    @Autowired 
    public OrderRepository orderRepository;
    
    public void SaveOrders(Orders order)
    {
       orderRepository.save(order); 
   }
    
    public List<Orders> getOrders(int custId)
    {
        return orderRepository.findByCustId(custId);
    }
    
       public List<Orders> getAllOrders()
    {
        List<Orders> restList = orderRepository.findAll();
        
        return restList;
    }
       
          public void deleteOrder(Orders order)
    {
        orderRepository.delete(order);
    }
}
