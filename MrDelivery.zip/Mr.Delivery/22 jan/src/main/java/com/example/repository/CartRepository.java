
package com.example.repository;

import java.util.ArrayList;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.model.ShoppingCart;

@Repository
public interface CartRepository extends CrudRepository <ShoppingCart, Integer>{
 
    // @Query - Used when I want to generate my own query
	@Query("SELECT l FROM ShoppingCart l WHERE l.userId = :userId")
	//@Param - the values that will go to the @Query statement will be parameters
	public ArrayList<ShoppingCart> viewByUserId(@Param("userId") int userId);
	
    
}
