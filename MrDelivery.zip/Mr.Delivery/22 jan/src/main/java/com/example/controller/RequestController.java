/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.controller;

import com.example.model.UploadModal;
import com.example.model.Restaurant;
import com.example.service.RequestService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;

@RestController
public class RequestController {
    
    @Autowired
    private RequestService requestService;
    
     public List<Restaurant> restList = new ArrayList<>();
    
    @RequestMapping (value="/SaveRequest", method = RequestMethod.POST)
    public void addRequest(@RequestBody Restaurant restaurant){
        System.out.println("rhtgere");
        requestService.addRequest(restaurant);
    }
    
    //Not Accepted
    @RequestMapping(value="/getRequest")
    public List<Restaurant> getRestaurantRequests()
    {
        restList = requestService.getRequests();
        return restList;
    }
       
    //Accepted
    @RequestMapping(value="/getAcceptedRestaurants")
    public List<Restaurant> getAcceptedRestaurants()
    {
        restList = requestService.getAcceptedRestaurants();
        return restList;
    }
        
           @RequestMapping(value="/acceptedRest", method = RequestMethod.GET)
        public ModelAndView acceptedRest(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("acceptedRest");
                return modelAndView;
        }
      
        @RequestMapping (value="/deleteRequest", method = RequestMethod.DELETE)
        public void deleteRequest (@RequestBody Restaurant restaurant){
            System.out.println("rhtgere");
            requestService.deleteRequest(restaurant);
        }
        
        
            // Update a Restaurant
    @RequestMapping(value="/updateRequest/{restId}", method = RequestMethod.PUT)
    public Restaurant updateRequest(@PathVariable(value = "restId") int restId) {
        Restaurant restaurant = requestService.findByRestaurantId(restId);
        
        if(restaurant != null) {
            restaurant.setStatus(true);
        }

        Restaurant updatedRequest = requestService.saveRequest(restaurant);
        return updatedRequest;
    }
    
    
     @RequestMapping (value="/deleteRestaurant", method = RequestMethod.DELETE)
        public void deleteRestaurant (@RequestBody Restaurant restaurant){
            System.out.println("rhtgere");
            requestService.deleteRestaurant(restaurant);
        }
       
       private final Logger logger = LoggerFactory.getLogger(RequestController.class);
       
       //Save the uploaded file to this folder
       private static String UPLOADED_FOLDER = "C://temp//";
       
       //SINGLE FILE UPLOAD
       @PostMapping("/api/upload")
       public ResponseEntity<?> uploadFile(
            @RequestParam("file") MultipartFile uploadfile){
                
            logger.debug("Single File Upload");
            
            if(uploadfile.isEmpty()){
                return new ResponseEntity("Please select a file!", HttpStatus.OK);
            }
            
         try {
                saveUploadedFiles(Arrays.asList(uploadfile));
                } catch (IOException e) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
                }
         
                return new ResponseEntity("Successfully uploaded - " +
                    uploadfile.getOriginalFilename(), new HttpHeaders(), HttpStatus.OK);
                    }
       
               
           // 3.1.2 Multiple file upload
                @PostMapping("/api/upload/multi")
                public ResponseEntity<?> uploadFileMulti(
                    @RequestParam("extraField") String extraField,
                    @RequestParam("files") MultipartFile[] uploadfiles) {
                logger.debug("Multiple file upload!");
                // Get file name
                String uploadedFileName = Arrays.stream(uploadfiles).map(x -> x.getOriginalFilename())
                .filter(x -> !StringUtils.isEmpty(x)).collect(Collectors.joining(" , "));
                if (StringUtils.isEmpty(uploadedFileName)) {
                return new ResponseEntity("please select a file!", HttpStatus.OK);
                }
                try {
                saveUploadedFiles(Arrays.asList(uploadfiles));
                } catch (IOException e) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
                }
                return new ResponseEntity("Successfully uploaded - "
                + uploadedFileName, HttpStatus.OK);
                }
                   
 
            // 3.1.3 maps html form to a Model
            @PostMapping("/api/upload/multi/model")
            public ResponseEntity<?> multiUploadFileModel(@ModelAttribute UploadModal model) {
                logger.debug("Multiple file upload! With UploadModel");
            try {
                saveUploadedFiles(Arrays.asList(model.getFiles()));
            } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
                return new ResponseEntity("Successfully uploaded!", HttpStatus.OK);
            }
            //save file
            private void saveUploadedFiles(List<MultipartFile> files) throws IOException {
            for (MultipartFile file : files) {
            if (file.isEmpty()) {
            continue; //next pls
            }
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);
}
}
        
}
