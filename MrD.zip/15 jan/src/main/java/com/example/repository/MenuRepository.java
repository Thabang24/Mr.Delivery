
package com.example.repository;

import com.example.model.Menu;
import java.util.ArrayList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;


public interface MenuRepository extends JpaRepository<Menu, Integer> {
    public ArrayList<Menu> findByRestId(@Param("restId") int restId);
}
