
package com.example.controller;

import com.example.model.Orders;
import com.example.service.OrderService;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {
    
    @Autowired 
    private OrderService orderService;
    
    public List<Orders> orderList = new ArrayList<>();

    @RequestMapping(value="/SaveOrder", method = RequestMethod.POST)
    public void addOrder(@RequestBody Orders order){
        System.out.println("saved");
        orderService.SaveOrders(order);
    }
    
    @RequestMapping(value="/getOrders/{custId}", method = RequestMethod.GET)
    public List<Orders> getCustomerOrders(@PathVariable(value = "custId") int custId)
    {
        return orderService.getOrders(custId);
    }
    
    
     @RequestMapping(value="/getAllOrders")
    public List<Orders> getAllOrders()
    {
        orderList = orderService.getAllOrders();
        return orderList;
    }
    
      @RequestMapping (value="/deleteOrder", method = RequestMethod.DELETE)
        public void deleteOrder (@RequestBody Orders order){
            System.out.println("rhtgere");
            orderService.deleteOrder(order);
        }
}


