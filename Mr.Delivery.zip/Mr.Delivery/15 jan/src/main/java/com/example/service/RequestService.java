/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.service;


import com.example.model.Restaurant;
import com.example.repository.RequestRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Thabang
 */
@Service
public class RequestService {
    
    @Autowired
    public RequestRepository requestRepository;
    
    public void addRequest(Restaurant restaurant)
    {
        requestRepository.save(restaurant);
    }
    

     
    public void deleteRequest(Restaurant restaurant)
    {
        requestRepository.delete(restaurant);
    }
    
    public Restaurant findByRestaurantId(int restId)
    {
        Restaurant restaurant = requestRepository.findOne(restId);
        return restaurant;
    }
    
    
    public Restaurant saveRequest(Restaurant restaurant)
    {
        return requestRepository.save(restaurant);
    }
           
    public List<Restaurant> getRequests()
    {
        List<Restaurant> restList = requestRepository.findByStatus(false);
        
        return restList;
    }
            
    public List<Restaurant> getAcceptedRestaurants()
    {
        List<Restaurant> restList = requestRepository.findByStatus(true);
        
        return restList;
    }
    

       public void deleteRestaurant(Restaurant restaurant)
    {
        requestRepository.delete(restaurant);
    }
}
