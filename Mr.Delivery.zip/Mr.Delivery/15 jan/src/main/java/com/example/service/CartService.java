
package com.example.service;

import com.example.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.model.ShoppingCart;
import java.util.List;
import java.util.ArrayList;

@Service
public class CartService {
 
    @Autowired
    public CartRepository cartRepository;
    
   public ArrayList<ShoppingCart> getCart(int userId)
   {
       return cartRepository.viewByUserId(userId);
   }
   
   public void SaveCart(ShoppingCart carts)
   {
       cartRepository.save(carts);
   }
   
   public void DeleteCart(int userId)
   {
       cartRepository.delete(userId);
   }
   
   public void updateCart(int userId, ShoppingCart carts)
   {
       cartRepository.save(carts);
   }
   
   public List<ShoppingCart> getAllCarts()
   {
      List<ShoppingCart> carts =new ArrayList<>();
      cartRepository.findAll()
              .forEach(carts::add);
      return carts;
   }
}
