package com.example.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.model.User;
import com.example.service.UserService;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class LoginController {
	
	@Autowired
	private UserService userService;
        
        
     
	@RequestMapping(value={"/", "/login"}, method = RequestMethod.GET)
	public ModelAndView login(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}
	
        @RequestMapping(value="/restowner", method = RequestMethod.GET)
        public ModelAndView restowner(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("restowner");
                return modelAndView;
        }
        
          @RequestMapping(value="/UploadForm", method = RequestMethod.GET)
        public ModelAndView UploadForm(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("UploadForm");
                return modelAndView;
        }
        
        
         @RequestMapping(value="/payment", method = RequestMethod.GET)
        public ModelAndView payment(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("payment");
                return modelAndView;
        }
        
        @RequestMapping(value="/Orders", method = RequestMethod.GET)
        public ModelAndView Orders(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("Orders");
                return modelAndView;
        }
        
        
         @RequestMapping(value="/orderDetails", method = RequestMethod.GET)
        public ModelAndView orderDetails(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("orderDetails");
                return modelAndView;
        }
        
          @RequestMapping(value="/orderConfirmation", method = RequestMethod.GET)
        public ModelAndView orderConfirmation(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("orderConfirmation");
                return modelAndView;
        }
	
         @RequestMapping(value="/how", method = RequestMethod.GET)
        public ModelAndView how(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("how");
                return modelAndView;
        }
        
        @RequestMapping(value="/Guest", method = RequestMethod.GET)
        public ModelAndView Guest(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("Guest");
                return modelAndView;
        }
	
            @RequestMapping(value="/franchise", method = RequestMethod.GET)
        public ModelAndView franchise(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("franchise");
                return modelAndView;
        }
	
        
           @RequestMapping(value="/allRestaurants", method = RequestMethod.GET)
        public ModelAndView allRestaurants(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("allRestaurants");
                return modelAndView;
        }
        
             @RequestMapping(value="/Menu", method = RequestMethod.GET)
        public ModelAndView Menu(){
                ModelAndView modelAndView = new ModelAndView();
                modelAndView.setViewName("Menu");
                return modelAndView;
        }
	
	@RequestMapping(value="/registration", method = RequestMethod.GET)
	public ModelAndView registration(){
		ModelAndView modelAndView = new ModelAndView();
		User user = new User();
		modelAndView.addObject("user", user);
		modelAndView.setViewName("registration");
		return modelAndView;
	}
        
        @RequestMapping(value="/admin", method = RequestMethod.GET)
	public ModelAndView admin(){
		ModelAndView modelAndView = new ModelAndView();
		User user = new User();
		modelAndView.addObject("user", user);
		modelAndView.setViewName("admin");
		return modelAndView;
	}
	
	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public ModelAndView createNewUser(@Valid User user, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		User userExists = userService.findUserByEmail(user.getEmail());
		if (userExists != null) {
			bindingResult
					.rejectValue("email", "error.user",
							"There is already a user registered with the email provided");
		}
		if (bindingResult.hasErrors()) {
			modelAndView.setViewName("registration");
		} else {
			userService.saveUser(user);
			modelAndView.addObject("successMessage", "User has been registered successfully");
			modelAndView.addObject("user", new User());
			modelAndView.setViewName("registration");
			
		}
		return modelAndView;
	}
	
	@RequestMapping(value="/home", method = RequestMethod.GET)
	public ModelAndView home(){
		ModelAndView modelAndView = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		User user = userService.findUserByEmail(auth.getName());
		modelAndView.addObject("userName", "Welcome " + user.getName() + " " + user.getLastName() + " (" + user.getEmail() + ")");
		modelAndView.addObject("userID",user.getId());
		modelAndView.setViewName("home");
		return modelAndView;
	}
        
        @RequestMapping(value="/flag")
	public String findUrlTarget(HttpServletResponse response,HttpServletRequest request ){
		
            Authentication authenticate= SecurityContextHolder.getContext().getAuthentication();
            String role= authenticate.getAuthorities().toString();
            String urlTarget="";
            if(role.contains("customer"))
                urlTarget = "redirect:/home";
            else if(role.contains("admin"))
                urlTarget = "redirect:/admin";

            return urlTarget;    
	}
        
	
}
