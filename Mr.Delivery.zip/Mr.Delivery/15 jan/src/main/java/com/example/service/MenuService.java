/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.service;

import com.example.model.Menu;
import com.example.repository.MenuRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Thabang
 */
@Service
public class MenuService {
    
  @Autowired
  public MenuRepository menuRepository;
  
  	public List<Menu> getAllmenus()
	{
		
		List<Menu> products = new ArrayList<>();
		menuRepository.findAll()
		.forEach(products::add);
		return products;
		
	}
    
  public void SaveItems(Menu menu)
  {
      menuRepository.save(menu);
  }
  public ArrayList<Menu> findByRestaurantId(int restId)
  {
      return menuRepository.findByRestId(restId);
  }
  
  
    public void deleteItem(Menu menu)
    {
        menuRepository.delete(menu);
    }
}
