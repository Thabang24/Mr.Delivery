
package com.example.controller;
import com.example.model.Payment;
import com.example.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PaymentController {
    
    @Autowired
    private PaymentService paymentService;
    
     @RequestMapping (value="/SavePayment", method = RequestMethod.POST)
    public void SavePayment(@RequestBody Payment payment){
        System.out.println("rhtgere");
        paymentService.SavePayment(payment);
    }
}
