var mrD= angular.module("myApp",[]);


mrD.controller("requestController", function($scope,$http)
{  
    $http.defaults.headers.post["Content-Type"] = "application/json";
       $scope.prodLength = [];
       var cartArray = [];
       console.log($scope.cartArray);
    var restaurantID;
    var cart_identity;

//New Restaurant request
    $scope.processRequest = function() 
    {
        
        var file = document.getElementById('fileName');
        var logoImage = "/images/"+ file.files.item(0).name;
    
    var addRequest = {
        package1: $scope.requestForm.package,
        restName: $scope.requestForm.rest_name,
        restAddress: $scope.requestForm.rest_address, 
        restCity: $scope.requestForm.rest_city,
        zipCode: $scope.requestForm.zip_code,
        ownerFirstName: $scope.requestForm.owner_firstName,
        ownerLastName: $scope.requestForm.owner_lastName, 
        ownerCellNum: $scope.requestForm.owner_cellNum,
        ownerEmail: $scope.requestForm.owner_email,
        restPhoneNum: $scope.requestForm.rest_phoneNum,
        restFaxNum: $scope.requestForm.rest_faxNum,
        openTime: $scope.requestForm.openTime,
        closeTime: $scope.requestForm.closeTime,
        menuFile: $scope.requestForm.menu_file,
        info: $scope.requestForm.info,
        status: 0,
        fileName: logoImage
    };
    
 console.log(addRequest);
    
    $http.post('http://localhost:3000/SaveRequest',addRequest).then(function(response)
    {
        alert("Request Submitted");
           
    });     
    

         
        };
        _getRestaurants();
        _getAcceptedRestaurants();
        _getAllOrders();
        
      //Get all Requested Restaurants  
       $scope.requestData=[];
       var requestData;
    function _getRestaurants(){
       $http({
            method : 'GET',
            url : 'http://localhost:3000/getRequest',
            data : angular.fromJson(requestData),
            headers : {'Content-Type' : 'application/json'}
        })
        .success(function(data){
            $scope.requestData= data;
           // alert("Request Submitted");
        }); 
    }
    
    //Get Accepted Restaurants
    $scope.acceptedRestaurants=[];
    var acceptedRestaurants;
    function _getAcceptedRestaurants(){
       $http({
            method : 'GET',
            url : 'http://localhost:3000/getAcceptedRestaurants',
            data : angular.fromJson(acceptedRestaurants),
            headers : {'Content-Type' : 'application/json'}
        })
        .success(function(data){
            $scope.acceptedRestaurants= data;
           // alert("Request Submitted");
        }); 
    }
    
    //Get all orders-- Admin
      $scope.allOrders=[];
    var allOrders;
    function _getAllOrders(){
       $http({
            method : 'GET',
            url : 'http://localhost:3000/getAllOrders',
            data : angular.fromJson(allOrders),
            headers : {'Content-Type' : 'application/json'}
        })
        .success(function(data){
            $scope.allOrders= data;
        }); 
    }
    
    
    
    
    //Reject restaurant request--ADMIN
    $scope.reject = function ( request )
    {
        var rejectRequest = { 
            restId: request.restId
        };
        
        console.log(request);
        $http({
            method : 'DELETE',
            url : 'http://localhost:3000/deleteRequest',
            data : angular.toJson(request),
            headers : {'Content-Type' : 'application/json'}
        })
            .success(function(data){
            $scope.rejectRequest= data;
            location.reload(true);
        });
    };
    
    //Accept restaurant request --ADMIN
    $scope.acceptRestaurant = function (request)
    {
        var restaurantId = {
            restId: request.restId
        };
        
        $http({
            method : 'PUT',
            url : 'http://localhost:3000//updateRequest/' + request.restId,
            data : angular.toJson(restaurantId),
            headers : {'Content-Type' : 'application/json'}
        })
           .success(function(data){
            $scope.rejectRequest= data;
            location.reload(true);
            _getRestaurants();
            _getAcceptedRestaurants();
        });
    };
    
    //Delete Restaurant -- ADMIN
     $scope.Remove = function ( restaurant )
    {
        var removeRestaurant = { 
            restId: restaurant.restId
        };
        
        console.log(removeRestaurant);
        $http({
            method : 'DELETE',
            url : 'http://localhost:3000/deleteRestaurant', 
            data : angular.toJson(restaurant),
            headers : {'Content-Type' : 'application/json'}
        })
            .success(function(data){
                alert("dfdf");
            $scope.acceptedRestaurants= data;
            location.reload(true);
        });
    };
    
    //Create/Update Menu--ADMIN
       $scope.restaurantInfo;
    $scope.createMenu = function (restaurant){
      
       $("#createMenu").modal('show');
       
       var restaurantId = restaurant.restId;
       var restaurantName = restaurant.restName;
       
       restaurantID = restaurant.restId;
       console.log($scope.restaurantID);
       
        var restaurant = 
           [ {
              restId: restaurantID,
             restName: restaurantName       
             }];
    $scope.restaurantInfo=restaurant;
    console.log($scope.restaurantInfo);
    

     };
     
     //Create Menu --ADMIN
    $scope.processMenu = function(restaurant) 
    {
      
        
    var SaveItems = {
        itemName: $scope.requestForm.item_name,
        itemDescription: $scope.requestForm.item_description,
        itemPrice: $scope.requestForm.item_price,
        restId: $scope.requestForm.rest_id
    };
  console.log(restaurantID);
 console.log(SaveItems);
    
        $http.post('http://localhost:3000/SaveItems',SaveItems).then(function(response)
    {
        alert("Menu Item Added");
           
    }); 
   
};


    //View Menu
    $scope.Items;
    $scope.viewMenu = function(restaurant)
    {
    var restaurantData=[]; 
    
      
          $('#myModal').modal('show');

       $http({
            method : 'GET',
            url : 'http://localhost:3000/viewMenu/' + restaurant.restId,
            data : angular.fromJson(restaurantData),
            headers : {'Content-Type' : 'application/json'}
       })
          .success(function(data){
            $scope.Items= data;
       });


    };
    
    //Delete Menu Item
         $scope.deleteItem = function ( menu )
    {
       
       
        $http({
            method : 'DELETE',
            url : 'http://localhost:3000/deleteItem', 
            data : angular.toJson(menu),
            headers : {'Content-Type' : 'application/json'}
        })
            .success(function(data){
                alert("dfdf");
                location.reload(true);
        });
    };
    

       $scope.menuItem;
 
       //Customer view Menu
    $scope.custViewMenu = function(restaurant)
    {
    var restaurantData=[];
    $scope.prodLength[0] = restaurant.restId;
    

      $http({
            method : 'GET',
            url : 'http://localhost:3000/viewMenu/' + restaurant.restId,
            data : angular.fromJson(restaurantData),
            headers : {'Content-Type' : 'application/json'}
       })
          .success(function(data){
            $scope.Items= data;
    console.log($scope.Items);
       });
console.log($scope.prodLength[0]);



    };
    
    
      //Add cart to Database
        $scope.create = function(item, quantity)
        {

            var addToCart = {
                "itemName": item.itemName,
                "quantity": quantity,
                "itemsPrice": item.itemPrice * quantity,
                "userId": $scope.userDetails[0].id
            };
       
            console.log(addToCart);
            
            $http.post('http://localhost:3000/SaveCart', addToCart).then(function(response){
             if(response.data.getcart_id !== 0)
             {
                 console.log("Cart product...");
                 alert("Item Added To Cart...");
                location.reload(true);
             }else{
                  console.log("Cart product Not Added");
                  alert("Item not added to cart...");
                   location.reload(true);
             }
         });
        };
        
        //Delete Cart Item
        $scope.DeleteItem = function (cart)
        {
            
            var cartidentity={
                cartId:cart.cartId
            };
          var ID = cartidentity;
            cart_identity=cartidentity;
            console.log($scope.cart);
            console.log(cartidentity);
            console.log(cart_identity);
           
                 $http.delete('http://localhost:3000/DeleteCart/' + ID).then(function(response){
                    console.log(response);
                    if(response.data !== 0)
                    {
                       
                        alert("Item has been Deleted");
                        location.reload(true);
                    }else{
                       
                        alert("Item Not Deleted..!!!");
                        location.reload(true);
                    }
                });
            
        };
        
        //Save payment infomation
         $scope.paymentInfo = function() 
         {
        
            var payDetails = {
            bank: $scope.requestForm.bank,
            cardNumber: $scope.requestForm.card_number,
            userId: $scope.userDetails[0].id,
            total: $scope.netAmount,
            paymentType: $scope.requestForm.payment_type
             };
  
            console.log(payDetails);
    
            $http.post('http://localhost:3000/SavePayment',payDetails).then(function(response)
            {       
                alert("Payment Details Saved");
               
            }); 
            window.location.href="http://localhost:3000/orderConfirmation";
         };
   
         //Save delivery address 
        $scope.addAddress = function() 
        {

            var Address = {
             deliveryTime:$scope.requestForm.deliveryTime,
             address:$scope.requestForm.address,
            custId:$scope.userDetails[0].id
         };
    
        console.log(Address);
    
        $http.post('http://localhost:3000/SaveAddress',Address).then(function(response)
         {
             alert("Address Saved");
         });     

        };




        //Login or Sign up alert for Visitor
        $scope.loginAlert = function ( ){
          alert("Please Login or Sign Up if you do not have an account");
         window.location.href="http://localhost:3000/login";
        };
        
        //Get User by email
        $http.get('/user').then(function successCallback(response){
            $scope.userEmail=response.data;
            console.log();
        }, function errorCallback(response){
        });
        
       //Get User by email
       var user_id_variable;
       var total_variable;
         $http.get('/viewUser').then(function successCallback(response){
            $scope.userDetails=response.data;
            var name = $scope.userDetails[0].id;
            user_id_variable = name;
            console.log("dff");
            //View cart items
            console.log(name);
            
         $http.get('/viewCart/' + name ).then(function successCallback(response) {
         $scope.cart=response.data;
         cartArray=$scope.cart;
         console.log($scope.cart);

         
         //Calculate total amount
         var totalAmount = 0;
        
         
         for (var i = 0; i < $scope.cart.length; i++ )
         { console.log($scope.cart[i].itemsPrice);
           totalAmount = totalAmount +   $scope.cart[i].itemsPrice; 
         };
        console.log(totalAmount);
         $scope.netAmount = totalAmount;
         $scope.netAmount = parseFloat(Math.round($scope.netAmount * 100)/100).toFixed(2); 
         total_variable=totalAmount;
        console.log($scope.netAmount);

     });

        
 });
        
        
       //Proccess and save customer order
        $scope.processOrder = function(order) 
    {
     
       $http({
            method : 'GET',
            url : 'http://localhost:3000/viewCart/' + $scope.userDetails[0].id ,
            data : angular.fromJson(requestData),
            headers : {'Content-Type' : 'application/json'}
        }) .success(function(data){
            $scope.cart= data;
           // alert("Request Submitted");
           console.log(data);
//          window.location.href="http://localhost:3000/orderDetails";

            $http({
            method : 'DELETE',
            url : 'http://localhost:3000/emptyCustomerCart/'+ $scope.userDetails[0].id, 
            data : angular.toJson(requestData),
            headers : {'Content-Type' : 'application/json'}
        }).success(function()
        {
            console.log("deleted");
        });
            
   
           $scope.addOrder=[]; 
           var addOrder;
           for(var order =0; order < data.length ; order++)
           {
                  addOrder = {
        custId: $scope.userDetails[0].id,
        total: $scope.netAmount,
        cartId:data[order].cartId,
        itemName:data[order].itemName,
        itemPrice:data[order].itemsPrice,
        quantity:data[order].quantity
                  };


             $http({
            method : 'POST',
            url : 'http://localhost:3000/SaveOrder',
            data : angular.toJson(addOrder),
            headers : {'Content-Type' : 'application/json'}
        });
    };
 console.log(addOrder);
 
   
         $scope.orderData=[];
       var orderData;
       $http({
            method : 'GET',
            url : 'http://localhost:3000/getOrders/' + $scope.userDetails[0].id ,
            data : angular.fromJson(orderData),
            headers : {'Content-Type' : 'application/json'}
        })
        .success(function(data){
            $scope.orderData= data;
            console.log(data);
            alert("Order Placed");
            $("#myModal").modal('show');
        }); 

        });

        
    
    };
    
//Delete order--ADMIN
       $scope.RemoveOrder = function ( order )
    {
        var removeOrder = { 
            orderId: order.orderId
        };
        
        console.log(removeOrder);
        $http({
            method : 'DELETE',
            url : 'http://localhost:3000/deleteOrder', 
            data : angular.toJson(order),
            headers : {'Content-Type' : 'application/json'}
        })
            .success(function(data){
                alert("Order Deleted");
                 location.reload(true);
        });
    };
    


 //end of js       
});

