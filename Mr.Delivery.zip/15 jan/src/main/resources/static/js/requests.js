var mrD= angular.module("myApp",[]);


mrD.controller("requestController", function($scope,$http)
{  
    $http.defaults.headers.post["Content-Type"] = "application/json";
       $scope.prodLength = [];
    var restaurantID;

    $scope.processRequest = function() 
    {

    var addRequest = {
        package1: $scope.requestForm.package,
        restName: $scope.requestForm.rest_name,
        restAddress: $scope.requestForm.rest_address, 
        restCity: $scope.requestForm.rest_city,
        zipCode: $scope.requestForm.zip_code,
        ownerFirstName: $scope.requestForm.owner_firstName,
        ownerLastName: $scope.requestForm.owner_lastName, 
        ownerCellNum: $scope.requestForm.owner_cellNum,
        ownerEmail: $scope.requestForm.owner_email,
        restPhoneNum: $scope.requestForm.rest_phoneNum,
        restFaxNum: $scope.requestForm.rest_faxNum,
        openTime: $scope.requestForm.openTime,
        closeTime: $scope.requestForm.closeTime,
        menuFile: $scope.requestForm.menu_file,
        info: $scope.requestForm.info,
        status: 0
    };
    
 console.log(addRequest);
    
    $http.post('http://localhost:3000/SaveRequest',addRequest).then(function(response)
    {
        alert("Request Submitted");
           
    });     
    

         
        };
        _getRestaurants();
        _getAcceptedRestaurants();
        
       $scope.requestData=[];
       var requestData;
    function _getRestaurants(){
       $http({
            method : 'GET',
            url : 'http://localhost:3000/getRequest',
            data : angular.fromJson(requestData),
            headers : {'Content-Type' : 'application/json'}
        })
        .success(function(data){
            $scope.requestData= data;
           // alert("Request Submitted");
        }); 
    }
    $scope.acceptedRestaurants=[];
    var acceptedRestaurants;
    function _getAcceptedRestaurants(){
       $http({
            method : 'GET',
            url : 'http://localhost:3000/getAcceptedRestaurants',
            data : angular.fromJson(acceptedRestaurants),
            headers : {'Content-Type' : 'application/json'}
        })
        .success(function(data){
            $scope.acceptedRestaurants= data;
           // alert("Request Submitted");
        }); 
    }
    
    $scope.reject = function ( request )
    {
        var rejectRequest = { 
            restId: request.restId
        };
        
        console.log(request);
        $http({
            method : 'DELETE',
            url : 'http://localhost:3000/deleteRequest',
            data : angular.toJson(request),
            headers : {'Content-Type' : 'application/json'}
        })
            .success(function(data){
            $scope.rejectRequest= data;
            location.reload(true);
        });
    };
    
    $scope.acceptRestaurant = function (request)
    {
        var restaurantId = {
            restId: request.restId
        };
        
        $http({
            method : 'PUT',
            url : 'http://localhost:3000//updateRequest/' + request.restId,
            data : angular.toJson(restaurantId),
            headers : {'Content-Type' : 'application/json'}
        })
           .success(function(data){
            $scope.rejectRequest= data;
            location.reload(true);
            _getRestaurants();
            _getAcceptedRestaurants();
        });
    };
    
     $scope.Remove = function ( restaurant )
    {
        var removeRestaurant = { 
            restId: restaurant.restId
        };
        
        console.log(removeRestaurant);
        $http({
            method : 'DELETE',
            url : 'http://localhost:3000/deleteRestaurant', 
            data : angular.toJson(restaurant),
            headers : {'Content-Type' : 'application/json'}
        })
            .success(function(data){
                alert("dfdf");
            $scope.acceptedRestaurants= data;
            location.reload(true);
        });
    };
    
       $scope.restaurantInfo;
    $scope.createMenu = function (restaurant){
      
       $("#createMenu").modal('show');
       
       var restaurantId = restaurant.restId;
       var restaurantName = restaurant.restName;
       
       restaurantID = restaurant.restId;
       console.log($scope.restaurantID);
       
        var restaurant = 
           [ {
              restId: restaurantID,
             restName: restaurantName       
             }];
    $scope.restaurantInfo=restaurant;
    console.log($scope.restaurantInfo);
    

     };
     
    $scope.processMenu = function(restaurant) 
    {
      
        
    var SaveItems = {
        itemName: $scope.requestForm.item_name,
        itemDescription: $scope.requestForm.item_description,
        itemPrice: $scope.requestForm.item_price,
        restId: $scope.requestForm.rest_id
    };
  console.log(restaurantID);
 console.log(SaveItems);
    
        $http.post('http://localhost:3000/SaveItems',SaveItems).then(function(response)
    {
        alert("Request Submitted");
           
    }); 
   
};



    $scope.Items;
    $scope.viewMenu = function(restaurant)
    {
    var restaurantData=[]; 
    
      
          $('#myModal').modal('show');

       $http({
            method : 'GET',
            url : 'http://localhost:3000/viewMenu/' + restaurant.restId,
            data : angular.fromJson(restaurantData),
            headers : {'Content-Type' : 'application/json'}
       })
          .success(function(data){
            $scope.Items= data;
       });


    };
    
    
         $scope.deleteItem = function ( menu )
    {
       
       
        $http({
            method : 'DELETE',
            url : 'http://localhost:3000/deleteItem', 
            data : angular.toJson(menu),
            headers : {'Content-Type' : 'application/json'}
        })
            .success(function(data){
                alert("dfdf");
                location.reload(true);
        });
    };
    

       $scope.menuItem;
 

    $scope.custViewMenu = function(restaurant)
    {
    var restaurantData=[];
    $scope.prodLength[0] = restaurant.restId;
    

      $http({
            method : 'GET',
            url : 'http://localhost:3000/viewMenu/' + restaurant.restId,
            data : angular.fromJson(restaurantData),
            headers : {'Content-Type' : 'application/json'}
       })
          .success(function(data){
            $scope.Items= data;
    console.log($scope.Items);
       });
console.log($scope.prodLength[0]);



    };
    
    
      //Add cart to Database
        $scope.create = function(item, quantity)
        {

            var addToCart = {
                "itemName": item.itemName,
                "quantity": quantity,
                "itemsPrice": item.itemPrice * quantity,
                "userId": $scope.userDetails[0].id
            };
       
            console.log(addToCart);
            
            $http.post('http://localhost:3000/SaveCart', addToCart).then(function(response){
             if(response.data.getcart_id !== 0)
             {
                 console.log("Cart product...");
                 alert("Item Added To Cart...");
//                 location.reload(true);
             }else{
                  console.log("Cart product Not Added");
                  alert("Item not added to cart...");
//                   location.reload(true);
             }
         });
        };
        
        //Delete Cart Item
        $scope.DeleteItem = function (name)
        {
            var ID = name.cart_id;
            console.log(ID);
                 $http.delete('http://localhost:3000/DeleteCart/' +ID).then(function(response){
                    console.log(response);
                    if(response.data !== 0)
                    {
                       
                        alert("Item has been Deleted");
                        location.reload(true);
                    }else{
                       
                        alert("Item Not Deleted..!!!");
                        location.reload(true);
                    }
                });
            
        };
        
        
         $scope.paymentInfo = function() 
         {
        
            var payDetails = {
            bank: $scope.requestForm.bank,
            cardNumber: $scope.requestForm.card_number,
            userId: $scope.userDetails[0].id,
            total: $scope.netAmount,
            paymentType: $scope.requestForm.payment_type
             };
  
            console.log(payDetails);
    
            $http.post('http://localhost:3000/SavePayment',payDetails).then(function(response)
            {       
                alert("Request Submitted");
//               window.location.href="http://localhost:3000/orderConfirmation";
           
            }); 
   
         };
   
   
        $scope.addAddress = function() 
        {

            var Address = {
             deliveryTime:$scope.requestForm.deliveryTime,
             address:$scope.requestForm.address,
            custId:$scope.userDetails[0].id
         };
    
        console.log(Address);
    
        $http.post('http://localhost:3000/SaveAddress',Address).then(function(response)
         {
             alert("Request Submitted");
           
         });     

        };





        $scope.loginAlert = function ( ){
          alert("Please Login or Sign Up if you do not have an account");
         window.location.href="http://localhost:3000/login";
        };
        
        //Get User by email
        $http.get('/user').then(function successCallback(response){
            $scope.userEmail=response.data;
            console.log();
        }, function errorCallback(response){
        });
        
       //Get User by email
       var user_id_variable;
       var total_variable;
         $http.get('/viewUser').then(function successCallback(response){
            $scope.userDetails=response.data;
            var name = $scope.userDetails[0].id;
            user_id_variable = name;
            console.log("dff");
            //View cart items
            console.log(name);
            
         $http.get('/viewCart/' + name ).then(function successCallback(response) {
         $scope.cart=response.data;
         console.log($scope.cart);
         var totalAmount = 0;
        
         
         for (var i = 0; i < $scope.cart.length; i++ )
         { console.log($scope.cart[i].itemsPrice);
           totalAmount = totalAmount +   $scope.cart[i].itemsPrice; 
         };
        console.log(totalAmount);
         $scope.netAmount = totalAmount;
         total_variable=totalAmount;
        console.log($scope.netAmount);

     });
//     window.location.href="http://localhost:3000/viewCart";
 });
 
      

   
 //end of js       
});

