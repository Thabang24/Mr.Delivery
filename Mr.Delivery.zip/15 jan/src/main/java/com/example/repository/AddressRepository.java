
package com.example.repository;

import com.example.model.Settings;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AddressRepository extends JpaRepository<Settings, Integer>{
    
      public List<Settings> findByAddressId(@Param("addressId") Boolean status);  
}
