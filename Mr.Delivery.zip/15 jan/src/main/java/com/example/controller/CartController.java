
package com.example.controller;

import com.example.model.ShoppingCart;
import com.example.service.CartService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CartController {
    
    @Autowired
    private CartService cartservice;
    
    @RequestMapping(method = RequestMethod.POST, value = "/SaveCart")
    
    public void SaveCart(@RequestBody ShoppingCart carts)
    {
        cartservice.SaveCart(carts);
    }
    
    @RequestMapping(method = RequestMethod.DELETE, value = "/DeleteCart")
    
        public void DeleteCart(@PathVariable int cart_id)
        {
            cartservice.DeleteCart(cart_id);
        }
    

    @RequestMapping(method = RequestMethod.PUT, value="/UpdateCart/{user_id}")
    
    public void UpdateCart(@RequestBody ShoppingCart carts, @PathVariable int user_id)
    {
        cartservice.updateCart(user_id, carts);
    }
    
    @RequestMapping("/GetCarts")
    
    public List<ShoppingCart> getAllCarts()
    {
        return cartservice.getAllCarts();
    }
}
