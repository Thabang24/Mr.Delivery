
package com.example.controller;

import com.example.model.Settings;
import com.example.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AddressController {
  
    @Autowired
    private AddressService addressService;
    
    @RequestMapping (value="/SaveAddress", method = RequestMethod.POST)
    public void SaveAddress(@RequestBody Settings settings){
        System.out.println("rhtgere");
        addressService.SaveAddress(settings);
    }
}
