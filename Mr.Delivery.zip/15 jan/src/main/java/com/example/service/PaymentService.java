/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.service;

import com.example.model.Payment;
import com.example.repository.PaymentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PaymentService {
    
      @Autowired
    public PaymentRepository paymentrepository;
 
    public void SavePayment(Payment payment)
    {
        paymentrepository.save(payment);
    }
    
}
